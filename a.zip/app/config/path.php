<?php
//define('URL','http://amn.ir/');
define('URL','http://localhost/amn/');
//define('URL','http://192.168.1.8/aks/');
define('LINK','javascript:void(0)');
define('LOGIN','onclick="document.getElementById(\'login_modal\').style.display=\'block\'"');
