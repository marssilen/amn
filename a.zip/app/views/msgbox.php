<div id="msgbox" class="w3-red w3-round" style="display:none">
   <span onclick="this.parentElement.style.display='none'" class="w3-closebtn w3-xxxlarge" style="padding-right:10px">&times;</span>
   <div class=" w3-padding-16">
  <h3 id="msg" class="w3-center">
  </h3>
  </div>
</div>
