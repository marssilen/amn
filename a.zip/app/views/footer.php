<div id="footer" class="" style="margin-bottom: 0px;background-color: #3D3D3D;color: white;text-align: center;padding-top:25px">
    ما را در دنبال کنید:
    <br>
    <a href="https://www.instagram.com//" class="fa fa-instagram"></a>
    <!--    Instagram-->
    <a href="https://www.facebook.com/" class="fa fa-facebook"></a>
    <!--    Facebook-->
    <a href="#" class="fa fa-twitter"></a>
    <!--    Twitter-->
    <a href="https://www.telegram.me/" class="fa fa-telegram"></a>
    <!--    Telegram-->
</div>