<?php
//error_reporting(E_ERROR | E_WARNING | E_PARSE);
require_once 'app/init.php';
$app = new App;